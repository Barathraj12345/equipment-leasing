from django.shortcuts import render,HttpResponse,redirect
from .models import register,fileupload
# Create your views here.
def registerpage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        passw = request.POST.get('passw')
        repass= request.POST.get('repass')
        address =request.POST.get('address')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        company = request.POST.get('company')
        users = register()
        users.Username = username
        users.Password = passw
        users.Re_password = repass
        users.Phone = phone
        users.Address = address
        users.Email = email
        users.Company = company
        users.save()
    return render(request, 'registerpage.html')

def lessorlogin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        try:
            register.objects.get(Username=username,Password=password)
            return render(request,'uploadimage.html')
        except:
            return HttpResponse('invalid')
    return render(request,'lessorlogin.html')


def upload(request):
    if request.method == 'POST':
        id = request.POST.get('id')
        name = request.POST.get('name')
        size = request.POST.get('size')
        price = request.POST.get('price')
        picture = request.FILES['picture']
        history = request.POST.get('history')
        files = fileupload()
        files.Container_id = id
        files.Container_Name = name
        files.Container_Size = size
        files.Container_Price = price
        files.Picture = picture
        files.Container_History= history
        files.save()
    return render(request, 'uploadimage.html')

def imageview(request):
    details = fileupload.objects.all()
    return render(request,'imageview.html',{'value':details})

def results(request):
    details = fileupload.objects.filter(Status=False)
    return render(request,'adminpage.html',{'values':details})

def approve(request,id):
    data = fileupload.objects.get(id=id)
    data.Status = True
    data.save()
    return redirect('/owner_lessor/adminpage/')

def results1(request):
    details = fileupload.objects.filter(Status=True)
    return render(request,'approved.html',{'values':details})

def adminlogin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        if username == 'admin' and password == 'admin123@':
            return render(request,'adminhome.html')
        else:
            return HttpResponse('Invalid')
    return render(request,'adminlogin.html')



def operations(request):
    details = fileupload.objects.all()
    return render(request,'operations.html',{'values':details})

def edit(request,id):
    details = fileupload.objects.all()
    users = fileupload.objects.get(id=id)
    if request.method == 'POST':
        id = request.POST.get('id')
        name = request.POST.get('Name')
        size = request.POST.get('Size')
        price = request.POST.get('Price')
        picture = request.FILES['Picture']
        history = request.POST.get('history')
        users.Container_id = id
        users.Container_Name = name
        users.Container_Size = size
        users.Container_Price = price
        users.Picture = picture
        users.Container_History = history
        users.save()
        return render(request,'/operations')
    return  render(request,'operations.html',{'values':details,'a':users})

def delete(request,id):
    data = fileupload.objects.filter(id=id).delete()
    return redirect('/operations')

def image(request):
    details1 = fileupload.objects.filter(Status=True)
    return render(request, 'approved.html', {'values': details1})

def container(request):
    details1 = fileupload.objects.filter(Status=False)
    return render(request, 'container.html', {'values': details1})

def Book(request,id):
    data1 = fileupload.objects.get(id=id)
    data1.Select = True
    data1.save()
    return redirect('/owner_lessor/container/')

def yourorder(request):
    details1 = fileupload.objects.filter(Select=True)
    return render(request,'yourorder.html',{'values':details1})



