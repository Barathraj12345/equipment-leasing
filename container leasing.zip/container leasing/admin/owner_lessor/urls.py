from django.urls import path
from . import views

urlpatterns = [
    path('',views.registerpage),
    path('adminlogin/',views.adminlogin),
    path('lessorlogin/', views.lessorlogin),
    path('upload/', views.upload),
    path('containerdetails/', views.imageview),
    path('adminpage/', views.results),
    path('approve/<int:id>/', views.approve),
    path('approved/', views.results1),
    path('container/',views.container),
    path('yourorder/',views.yourorder),
    path('Book/<int:id>/', views.Book),
    path('operations/',views.operations),
    path('edit/<int:id>/',views.edit),
    path('image/',views.image),
    path('delete/<int:id>/',views.delete)
]
