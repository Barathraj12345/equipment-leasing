from django.db import models


# Create your models here.
class register(models.Model):

    Username =models.CharField(max_length=20)
    Password =models.CharField(max_length=30)
    Re_password =models.CharField(max_length=20)
    Email = models.EmailField(max_length=75)
    Address = models.CharField(max_length=1024)

class fileupload(models.Model):
    Container_id = models.CharField(max_length=40)
    Container_Name = models.CharField(max_length=40)
    Container_Size = models.CharField(max_length=40)
    Container_Price = models.CharField(max_length=40)
    Picture = models.FileField(default="anything")
    Container_History = models.TextField(max_length=300)
    Status = models.BooleanField(default=False)
    Select = models.BooleanField(default=False)




