from django.urls import path
from owner_lessor import *
from user_lessee import *
from . import views

urlpatterns = [
    path('',views.homepage),

    ]
