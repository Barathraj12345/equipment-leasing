from django.urls import path
from . import views

urlpatterns = [
    path('userpage/',views.user_registerpage),
    path("userlogin/",views.userlogin),

    ]