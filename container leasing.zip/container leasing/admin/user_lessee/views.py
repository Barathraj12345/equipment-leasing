from django.shortcuts import render
from .models import register

# Create your views here.
def user_registerpage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        passw = request.POST.get('passw')
        repass= request.POST.get('repass')
        address =request.POST.get('address')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        company = request.POST.get('company')
        users = register()
        users.Username = username
        users.Password = passw
        users.Re_password = repass
        users.Phone = phone
        users.Address = address
        users.Email = email
        users.Company = company
        users.save()
    return render(request, 'user_registerpage.html')

def userlogin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        try:
            register.objects.get(Username=username,Password=password)
            return render(request,"Userhome.html")
        except:
            return HttpResponse('invalid')
    return render(request,'userlogin.html')



