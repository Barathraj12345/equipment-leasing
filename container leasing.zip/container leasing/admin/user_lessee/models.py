from django.db import models

# Create your models here.
class register(models.Model):

    Username =models.CharField(max_length=20)
    Password =models.CharField(max_length=30)
    Re_password =models.CharField(max_length=20)
    Email = models.EmailField(max_length=75)
    Address = models.CharField(max_length=1024)
    Company = models.CharField(max_length=30)
